from kivy.app import App
from kivy.properties import ObjectProperty, StringProperty, NumericProperty, BooleanProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.widget import Widget
from kivy.uix.behaviors import CoverBehavior

from models import Pizza


class PizzaWidget(BoxLayout):
    nom = StringProperty()
    ingredients = StringProperty()
    prix = NumericProperty()
    vegetarienne = BooleanProperty()


class MainWidget(FloatLayout):
    recycleView = ObjectProperty(None)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.pizzas = [
            Pizza("4 fromages", "brie, chèvre, emmental, comté", 9.5, True),
            Pizza("chorizo", "tomates, chorizo parmesan", 11.2, False),
            Pizza("Calzone", "fromage, champignon,  crème", 10, False)
        ]

    def on_parent(self, widget, parent):
        low = [pizza.get_dictionnary() for pizza in self.pizzas]
        self.recycleView.data = low


class PizzaApp(App):
    pass


PizzaApp().run()